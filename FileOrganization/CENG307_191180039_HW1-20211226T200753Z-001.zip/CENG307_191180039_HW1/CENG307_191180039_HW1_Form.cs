﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CENG307_191180039_HW1
{
    public partial class CENG307_191180039_HW1_Form : Form
    {
        public int[] arr; // array for generated numbers
        public int numberOfKeys; //how many numbers are put into hash function
        public int foundAt; //index of the value being searched
        public int P; // the P in f(key) = key mod P
        public int range; //generated values between [0 - ?]


        public CENG307_191180039_HW1_Form()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        //to set the hash key
        private void hashKey()

        // f(key) = key mod P and P must be smallest prime number > = table size
        {
            int num = (numberOfKeys + numberOfKeys / 11) + 1;

            do
            {
                num++;
            } while (!isPrime(num));
            P = num;


        }
        public static bool isPrime(int number)
        {
            if (number <= 1)
                return false;
            if (number == 2)
                return true;
            if (number % 2 == 0)
                return false;

            int boundary = (int)Math.Floor(Math.Sqrt(number));

            for (int i = 3; i <= boundary; i += 2)
                if (number % i == 0)
                    return false;

            return true;
        }

        void createTableRows(DataGridView table)
        {
            table.RowCount = P;

            for (int i = 0; i < P; i++)
            {
                table.Rows[i].Cells[0].Value = i;
                table.Rows[i].Cells[1].Value = null;
                table.Rows[i].Cells[2].Value = null;
            }
        }

        //generate random values and put them in an array
        private void generateArray(int valueCount)
        {           
            int value;
            arr = new int[valueCount];
            Random random = new Random();

            for (int i = 0; i < valueCount; i++)
            {
                value = random.Next(0, range);
                arr[i] = value;
            }

        }

        //calculating the number of the probes
        public int Probes(int column)
        {
            int sum = 0;

            for (int i = 0; i < numberOfKeys; i++)
                sum += Convert.ToInt32(dataGridView1.Rows[i].Cells[column].Value);

            return sum;
        }



        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void backgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {

        }

        private void tableLayoutPanel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            numberOfKeys = Int32.Parse(textBox3.Text);
            range = Int32.Parse(textBox1.Text);
            generateArray(numberOfKeys);
            hashKey();
            createTableRows(dataGridView1);
            BEISCH();
            textBox4.Text = Probes(0).ToString();
            double performance = (Math.Round(((double)numberOfKeys / P) * 100));
            textBox5.Text = "%" + performance.ToString();
            textBox7.Text = P.ToString();

        }


        private void BEISCH()
        {
            int hashedIndex;

            // if the flag is 1 it adds from the top, otherwise, adds from the bottom 
            int flag = 1;

            for (int i = 0; i < numberOfKeys; i++)
            {
                // f(key) = key Mod P
                hashedIndex = arr[i] % P;


                if (dataGridView1.Rows[hashedIndex].Cells[1].Value == null)
                {
                    dataGridView1.Rows[hashedIndex].Cells[1].Value = arr[i];
                }
                
                else if (flag == 1)
                {
                    int line = 0;
                    while (dataGridView1.Rows[line].Cells[1].Value != null)
                    {
                        line++;
                    }
                        
                    dataGridView1.Rows[line].Cells[1].Value = arr[i];                    
                    dataGridView1.Rows[line].Cells[2].Value = dataGridView1.Rows[hashedIndex].Cells[2].Value;
                    dataGridView1.Rows[hashedIndex].Cells[2].Value = dataGridView1.Rows[line].Cells[0].Value;
                    flag = 0;
                    
                }
                else
                {

                    int line = P - 1;

                    while (dataGridView1.Rows[line].Cells[1].Value != null)
                        line--;

                    dataGridView1.Rows[line].Cells[1].Value = arr[i];

                    
                    dataGridView1.Rows[line].Cells[2].Value = dataGridView1.Rows[hashedIndex].Cells[2].Value;
                    dataGridView1.Rows[hashedIndex].Cells[2].Value = dataGridView1.Rows[line].Cells[0].Value;
                    flag = 1;
                    

                }
            }
        }



        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView4_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        
        //searching for a value
        private void button2_Click(object sender, EventArgs e)
        {
            int searchedValue = Int32.Parse(textBox2.Text);
            int index = searchedValue % P;

            while (Convert.ToInt32(dataGridView1.Rows[index].Cells[1].Value) != searchedValue)
            {
                index = Convert.ToInt32(dataGridView1.Rows[index].Cells[2].Value);
            }
            textBox6.Text = index.ToString();

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
